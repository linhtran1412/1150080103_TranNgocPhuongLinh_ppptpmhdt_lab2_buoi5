﻿using System;
using System.IO; // de doc/ghi file

namespace _1150080103_TranNgocPhuongLinh
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Doc mang tu file input_array.txt
            string text = File.ReadAllText("input_array.txt").Replace("\uFEFF", "");
            string[] tokens = text.Split(new[] { ' ', '\t', '\r', '\n' },
                                         StringSplitOptions.RemoveEmptyEntries);
            int[] arr = Array.ConvertAll(tokens, int.Parse);

            Console.WriteLine("Mang ban dau:");
            Console.WriteLine(string.Join(" ", arr));

            // Sap xep tang dan bang Selection Sort
            for (int i = 0; i < arr.Length - 1; i++)
            {
                int minIndex = i;
                for (int j = i + 1; j < arr.Length; j++)
                {
                    if (arr[j] < arr[minIndex])
                        minIndex = j;
                }

                // Hoan doi
                int temp = arr[i];
                arr[i] = arr[minIndex];
                arr[minIndex] = temp;
            }

            Console.WriteLine("Mang sau khi sap xep tang dan:");
            Console.WriteLine(string.Join(" ", arr));

            // =========================
            // Thuc hanh 11: Chen them mot so vao mang da sap xep
            // =========================
            Console.Write("Nhap so nguyen can chen: ");
            int x = Convert.ToInt32(Console.ReadLine());

            int[] newArr = new int[arr.Length + 1];
            int k = 0;
            bool daChen = false;

            for (int i = 0; i < arr.Length; i++)
            {
                if (!daChen && x < arr[i])
                {
                    newArr[k++] = x;
                    daChen = true;
                }
                newArr[k++] = arr[i];
            }

            // Neu x lon hon tat ca cac phan tu thi chen cuoi
            if (!daChen)
            {
                newArr[k] = x;
            }

            Console.WriteLine("Mang sau khi chen {0}:", x);
            Console.WriteLine(string.Join(" ", newArr));

            // Dung man hinh
            Console.WriteLine("Nhan phim bat ky de thoat...");
            Console.ReadKey();
        }
    }
}
