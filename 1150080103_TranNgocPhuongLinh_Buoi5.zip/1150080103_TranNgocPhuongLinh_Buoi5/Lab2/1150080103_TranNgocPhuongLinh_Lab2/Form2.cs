﻿using System;
using System.Windows.Forms;

namespace _1150080103_TranNgocPhuongLinh_Lab2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // Mặc định chọn USCLN, ô Kết quả chỉ đọc, Enter = Tìm, Esc = Thoát
            radioButton1.Checked = true;       // USCLN
            textBox3.ReadOnly = true;
            this.AcceptButton = btnTim;
            this.CancelButton = btnThoat;
        }

        private void label2_Click(object sender, EventArgs e) 

        // ----------------- Helpers -----------------
        private bool TryGetInputs(out int a, out int b)
        {
            a = 0; b = 0;
            if (!int.TryParse(textBox1.Text.Trim(), out a))
            {
                MessageBox.Show("Số nguyên a không hợp lệ!");
                textBox1.Focus(); textBox1.SelectAll();
                return false;
            }
            if (!int.TryParse(textBox2.Text.Trim(), out b))
            {
                MessageBox.Show("Số nguyên b không hợp lệ!");
                textBox2.Focus(); textBox2.SelectAll();
                return false;
            }
            return true;
        }

        // USCLN (GCD) – thuật toán Euclid
        private int GCD(int x, int y)
        {
            x = Math.Abs(x); y = Math.Abs(y);
            if (x == 0) return y;
            if (y == 0) return x;

            while (y != 0)
            {
                int r = x % y;
                x = y;
                y = r;
            }
            return x;
        }

        // BSCNN (LCM): |a*b| / GCD(a,b)
        private long LCM(int x, int y)
        {
            x = Math.Abs(x); y = Math.Abs(y);
            if (x == 0 || y == 0) return 0;
            long g = GCD(x, y);
            return (long)x / g * (long)y;   // tránh tràn sớm
        }

        // ----------------- Events -----------------
        private void btnTim_Click(object sender, EventArgs e)
        {
            if (!TryGetInputs(out int a, out int b)) return;

            if (radioButton1.Checked)            // USCLN
                textBox3.Text = GCD(a, b).ToString();
            else                                  // BSCNN
                textBox3.Text = LCM(a, b).ToString();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
