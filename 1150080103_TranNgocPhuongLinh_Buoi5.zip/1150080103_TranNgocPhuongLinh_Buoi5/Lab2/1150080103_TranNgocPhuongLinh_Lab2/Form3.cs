﻿using System;
using System.Collections.Generic;
using System.Media;
using System.Windows.Forms;

namespace _1150080103_TranNgocPhuongLinh_Lab2
{
    public partial class Form3 : Form
    {
        // Bảng password -> nhóm
        private readonly Dictionary<string, string> _codeToGroup = new Dictionary<string, string>
        {
            { "1496", "Phát triển công nghệ" },
            { "2673", "Phát triển công nghệ" },
            { "7462", "Nghiên cứu viên" },
            { "8884", "Thiết kế mô hình" },
            { "3842", "Thiết kế mô hình" },
            { "3383", "Thiết kế mô hình" },
        };

        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // Ô password
            textBox1.Clear();
            textBox1.MaxLength = 4;
            textBox1.UseSystemPasswordChar = true;
            textBox1.Focus();

            // ListView (Login Log)
            listView1.View = View.Details;
            listView1.FullRowSelect = true;
            listView1.GridLines = true;
            if (listView1.Columns.Count == 0)
            {
                listView1.Columns.Add("Ngày giờ", 160);
                listView1.Columns.Add("Nhóm", 200);
                listView1.Columns.Add("Kết quả", 120);
            }

            // Tô màu các nút chức năng (để chắc ăn trên mọi theme)
            button10.UseVisualStyleBackColor = false; // Clear
            button11.UseVisualStyleBackColor = false; // Enter
            button12.UseVisualStyleBackColor = false; // Ring

            // Gán 1 handler cho tất cả các nút số
            button1.Click += OnDigitClick; button1.Tag = "1";
            button2.Click += OnDigitClick; button2.Tag = "2";
            button3.Click += OnDigitClick; button3.Tag = "3";
            button4.Click += OnDigitClick; button4.Tag = "4";
            button5.Click += OnDigitClick; button5.Tag = "5";
            button6.Click += OnDigitClick; button6.Tag = "6";
            button7.Click += OnDigitClick; button7.Tag = "7";
            button8.Click += OnDigitClick; button8.Tag = "8";
            button9.Click += OnDigitClick; button9.Tag = "9";

            // Gán handler cho Clear/Enter/Ring (nếu chưa gắn trong Designer)
            button10.Click += button10_Click; // Clear
            button11.Click += button11_Click; // Enter
            button12.Click += button12_Click; // Ring

            // Cho phép dùng phím vật lý 0-9, Enter, Backspace, Esc
            this.KeyPreview = true;
            this.KeyDown += Form3_KeyDown;
        }

        // Bấm các nút 1..9
        private void OnDigitClick(object sender, EventArgs e)
        {
            if (textBox1.TextLength >= 4) return;
            var btn = (Button)sender;
            var digit = btn.Tag?.ToString() ?? btn.Text.Trim();
            if (digit.Length == 1 && char.IsDigit(digit[0]))
                textBox1.Text += digit;
        }

        // Clear
        private void button10_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox1.Focus();
            SystemSounds.Asterisk.Play();
        }

        // Enter
        private void button11_Click(object sender, EventArgs e)
        {
            var code = textBox1.Text.Trim();

            string group;
            bool accepted = _codeToGroup.TryGetValue(code, out group);
            if (!accepted) group = "Không có";

            LogAttempt(group, accepted);

            if (accepted) SystemSounds.Exclamation.Play();
            else SystemSounds.Hand.Play();

            textBox1.Clear();
            textBox1.Focus();
        }

        // Ring (chuông cảnh báo)
        private void button12_Click(object sender, EventArgs e)
        {
            SystemSounds.Hand.Play();
        }

        // Hỗ trợ nhập bằng bàn phím
        private void Form3_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode >= Keys.D0 && e.KeyCode <= Keys.D9)
            {
                AppendDigit((char)e.KeyValue);
                e.Handled = true;
            }
            else if (e.KeyCode >= Keys.NumPad0 && e.KeyCode <= Keys.NumPad9)
            {
                var digit = (char)('0' + (e.KeyCode - Keys.NumPad0));
                AppendDigit(digit);
                e.Handled = true;
            }
            else if (e.KeyCode == Keys.Enter)
            {
                button11.PerformClick(); // Enter
                e.Handled = true;
            }
            else if (e.KeyCode == Keys.Back)
            {
                if (textBox1.TextLength > 0)
                    textBox1.Text = textBox1.Text.Substring(0, textBox1.TextLength - 1);
                e.Handled = true;
            }
            else if (e.KeyCode == Keys.Escape)
            {
                button10.PerformClick(); // Clear
                e.Handled = true;
            }
        }

        private void AppendDigit(char d)
        {
            if (!char.IsDigit(d)) return;
            if (textBox1.TextLength >= 4) return;
            textBox1.Text += d;
        }

        private void LogAttempt(string group, bool accepted)
        {
            string time = DateTime.Now.ToString("g"); // ví dụ 9/29/2025 9:35 PM
            string result = accepted ? "Chấp nhận!" : "Từ chối!";
            var item = new ListViewItem(new[] { time, group, result });
            listView1.Items.Insert(0, item); // thêm lên đầu

            // (tuỳ chọn) auto-fit cột
            //listView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);
            //listView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
        }
    }
}
